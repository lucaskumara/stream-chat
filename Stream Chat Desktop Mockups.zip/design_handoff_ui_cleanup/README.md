# Handoff: Stream Chat UI cleanup (v2)

Target repo: **lucaskumara/stream-chat** (branch `main`) — Electron + React + TypeScript renderer.

## Overview

This is a visual and structural cleanup of the existing renderer UI. Nothing new is
invented functionally except two navigation destinations; the work is mostly
consolidation: fewer visible controls, one consistent control vocabulary, and a
top-level mode switcher that replaces the ad-hoc per-pane toolbars.

Three things change at the app level:

1. **Title bar owns navigation.** A segmented switcher (Chat / Broadcast / Settings)
   sits at the far left of the frameless title bar, then a hairline divider, then the
   existing channel tabs, then the window controls. There is no sidebar.
2. **Per-pane toolbar shrinks to a header.** Each chat pane keeps only two icon
   buttons (filter, settings); text size, reset, clear chat and the OBS dock link move
   into the pane's settings popover.
3. **A real Settings screen.** Full-view settings with its own left sub-nav
   (General, Appearance, Accounts, Notifications, Keyboard shortcuts).

## About the design files

`Stream Chat v2.dc.html` in this bundle is a **design reference written in plain HTML +
inline styles**. It is a prototype of look and behavior — not production code to copy.
Recreate it in the repo's existing environment (React 18 + TypeScript function
components under `src/renderer/src/components/`, styling as the repo already does it),
reusing the existing components named in the screen map below rather than adding a new
styling approach.

`Stream Chat.dc.html` is the previous (pre-cleanup) mock, included only as a before/after
reference.

## Fidelity

**High fidelity.** Colors, sizes, radii, and spacing below are final and are taken from
the repo's own tokens. Recreate pixel-for-pixel. All measurements are CSS px at 1x.

---

## Design tokens

Palette (unchanged from `theme.ts` / `index.css`):

| Token | Value | Use |
| --- | --- | --- |
| ink-900 | #141414 | window background, chat pane background |
| ink-800 | #181818 | inset fields, segmented-control trough |
| ink-700 | #1c1c1c | active tab / active sub-nav item, modal surface |
| ink-600 | #242424 | popover surface, icon-button hover (settings popover) |
| line | #262626 | hairline dividers, pane borders |
| line-2 | #303030 | control borders, active tab border |
| hover-row | #1e1e1e | hover background for tabs and sub-nav items |
| segment-on | #333333 | selected segment / selected theme chip |
| fg | #e6e6e6 | body text |
| fg-2 | #9d9d9d | secondary text, control labels |
| fg-3 | #767676 | idle icon buttons |
| fg-4 | #5f5f5f | timestamps, captions, empty-state text |
| heading | #f2f2f2 | screen titles, active control text |
| twitch | #9146ff | platform dot |
| youtube | #ff0033 | platform dot |
| kick | #53fc18 | platform dot |
| close-hover | #c42b1c | window close button hover |
| offline dot | #4a4a4a | replaces the platform color when a channel is offline |

Event accent colors (message rows and their badges):

| Event | Accent | Badge bg | Badge text |
| --- | --- | --- | --- |
| Sub | #a78bfa | rgba accent @ 15% (`#a78bfa26`) | #bfa4ff |
| Raid | #fbbf24 | `#fbbf2426` | #f7c95a |
| Tip | #34d399 | `#34d39926` | #6ee7b7 |
| Notice | #60a5fa | `#60a5fa26` | #8cc0fd |

Accent rows use `border-left: 2px solid <accent>` and `background: <accent> at 7%`
(`#a78bfa12`). Non-event rows carry `border-left: 2px solid transparent` so text never
shifts horizontally between row types.

Typography: system sans (`ui-sans-serif, system-ui, "Segoe UI", Roboto, sans-serif`),
antialiased. Base UI size 14px. Screen titles 17px/600. Section labels 12px, uppercase,
letter-spacing .08em, color fg-4. Captions and secondary rows 13px. Chat message size is
per-pane and user-controlled: steps 12 / 14 / 16 / 18 / 20 / 24px, default 15px,
line-height 1.45. Timestamps and numeric readouts use `font-variant-numeric: tabular-nums`.
Inside a message, sub-elements scale with the row: timestamp and captions `.86em`,
badges `.75em`.

Radii: 5px selected segment, 6px icon buttons / tabs / fields / small buttons,
7px segmented-control outer and empty-state button, 9px account list, 10px popovers and
modal, 999px pills.

Spacing: title bar height 38px; pane header height 44px; control rows 28px tall with
20px gap between label and control; message rows 12px horizontal padding and
5px vertical (2px in compact density); settings content padded 22px/28px with a 520px
max content width.

Transitions: 120ms on background/color for all hover states; 180ms on the toggle knob
position; 150ms on any size/marker animation. No easing curve is specified — the default
is fine.

---

## Screens

### 1. Window shell / title bar

Frameless, 38px tall, background ink-900, `border-bottom: 1px solid line`,
`padding-left: 8px`, children in a flex row with 8px gap, vertically centered.

Left to right:

- **Mode switcher.** A segmented control: outer container `background: ink-800`,
  `border: 1px solid line-2`, `border-radius: 7px`, `padding: 2px`, 2px gap. Three
  buttons, each 26px tall, `padding: 0 11px`, `border-radius: 5px`, 14px text, icon +
  label in a flex row with 7px gap. Idle: transparent background, fg-3 text; label
  brightens to #e0e0e0 on hover. Selected: `background: segment-on`, text #f2f2f2.
  Items: **Chat** (speech-bubble icon), **Broadcast** (concentric signal arcs around a
  2.2r dot), **Settings** (gear). All icons 15px, `stroke-width: 1.8`, currentColor,
  no fill.
- **Divider.** 1px x 20px, `background: line`. **Only rendered when the channel tabs
  are rendered** (Chat view with at least one channel) — otherwise it is a stray line.
- **Channel tabs.** Only in Chat view. Flex row, 3px gap. Each tab is 28px tall,
  `padding: 0 6px 0 10px`, `border-radius: 6px`, `border: 1px solid transparent`,
  14px text, 8px internal gap. Idle text fg-2; hover `background: hover-row`,
  text #e0e0e0. Shown: `background: ink-700`, `border-color: line-2`, text #f0f0f0.
  Tab contents: 6px platform dot (opacity .55 when the tab is not shown; replaced by
  offline dot color when the channel is offline), label, then two 18px x 18px action
  squares — **split** (a rectangle bisected vertically, "Show alongside") and
  **remove** (an X). Both actions are `opacity: 0` until the tab is hovered
  (`border-radius: 4px`, color fg-4, hover `background: #303030` + text #e0e0e0). The
  split action stays visible at color #b4b4b4 while that channel is part of a split
  view. After the tabs: a 28px icon button with a plus glyph, "Add a channel".
- **Spacer**, then **window controls**: three 44px x 34px buttons, glyphs drawn on a
  10x10 viewBox at `stroke-width: 1`, color fg-3. Hover `background: ink-600`, text
  #ededed; the close button hovers to `background: close-hover`, text #fff.

Behavior: clicking a channel tab selects that channel *and* returns the app to Chat
view. Clicking a mode segment switches views; the mock does not preserve per-view
scroll.

### 2. Chat view

Flex row of panes, each `flex: 1; min-width: 0`, separated by a 1px `line` divider.
The divider only appears *between* visible panes, never leading or trailing.

**Pane header** — 44px tall, `padding: 0 8px 0 12px`, `border-bottom: 1px solid line`,
flex row with 10px gap: 6px platform dot, channel name (600 weight, #f0f0f0), platform
name (fg-4), an optional `offline` pill (18px tall, `padding: 0 7px`, `border: 1px solid
line-2`, `border-radius: 999px`, 12px text, fg-3), spacer, then two 28px icon buttons:
**filter** (magnifier) and **settings** (gear). Icon buttons are 28x28,
`border-radius: 6px`, fg-3; hover `background: ink-600` + #ededed; active (its panel is
open) keeps that same style permanently.

**Filter bar** — appears under the header when filter is toggled on:
`padding: 8px 12px`, `border-bottom: 1px solid line`, containing a 30px inset field
(`background: ink-800`, `border: 1px solid line-2`, `border-radius: 6px`,
`padding: 0 10px`, 8px gap). Empty state shows a magnifier + "Filter messages" in fg-3.
Active state shows filter chips (20px tall, `background: #2f2f2f`, `border-radius: 999px`,
13px, e.g. `from: Denise A.` with a small X) and a right-aligned match count
("3 of 214") in 13px fg-4.

**Message list** — absolutely positioned inside a `position: relative; flex: 1` box,
`justify-content: flex-end` so messages sit at the bottom, `padding-bottom: 8px`,
`overflow: hidden` in the mock (real implementation scrolls). Row anatomy, in order:
timestamp (`.86em`, fg-4, 6px right margin, hidden when timestamps are off), optional
event glyph (1em lucide-style icon in the accent color, 5px right margin,
`vertical-align: -1px`), optional event badge (uppercase, 700, `.75em`,
`letter-spacing: .06em`, `padding: 1px 5px`, `border-radius: 3px`), username (600, per
chatter color, underline on hover, click opens the chatter), a fg-4 colon, then the
message body. Mentions render as `background: rgba(255,255,255,.1)`,
`padding: 1px 4px`, `border-radius: 3px`, #f2f2f2. Links are #c9c9c9, underlined with
`text-underline-offset: 2px`. A reply shows a preceding `.86em` fg-4 line prefixed
"↳ " with the quoted text truncated. Deleted messages render at `opacity: .38` with the
original text struck through and a "(deleted)" suffix, and are hidden entirely when the
"Deleted messages" setting is off. Tip rows show the amount as an inline pill
(`background: rgba(52,211,153,.18)`, `padding: 1px 5px`, `border-radius: 3px`, 600,
#6ee7b7).

**Paused pill** — when the user has scrolled up: centered 10px from the bottom of the
pane, 26px tall, `padding: 0 12px`, `border-radius: 999px`, `background: #2b2b2b`,
`border: 1px solid line-2`, text #ededed 13px, `box-shadow: 0 6px 18px rgba(0,0,0,.5)`,
a down-arrow icon plus "18 new · paused". Deliberately monochrome — it must not read as
an event row.

**Pane settings popover** — anchored `top: 48px; right: 10px`, 340px wide,
`background: ink-600`, `border: 1px solid line-2`, `border-radius: 10px`,
`box-shadow: 0 14px 36px rgba(0,0,0,.55)`, `padding: 14px 16px 16px`, `z-index: 5`.
Sections separated by a 1px `line` rule with 12px margins:

1. *Every chat* — toggles: Timestamps, Deleted messages. These are global; changing
   them in one pane changes all panes.
2. *This chat* — Text size stepper (a 2px-padded ink-800 trough with -/+ 22x20 buttons
   and a 34px-wide tabular readout, e.g. "15px"), then two half-width 28px buttons:
   Reset size, Clear chat. Clear chat empties that pane and closes the popover.
3. *OBS dock link* — a read-only inset field showing
   `http://localhost:4568/chat/<platform>/<channel>` (truncated, nowrap) and a copy
   icon button that swaps to a checkmark for 1.6s after a click.

**Empty pane** (after Clear chat, or before the first message): centered column, 10px
gap, fg-4 — a 26px square with `border: 1.5px solid #2e2e2e`, `border-radius: 7px`, and
the text "Waiting for messages…".

**No channels at all**: centered column, 14px gap — a 34px version of the same square,
"No channels yet" in #e0e0e0, "Add one by name, or paste its link." in fg-4, then a
32px button (`padding: 0 14px`, `background: ink-600`, `border: 1px solid line-2`,
`border-radius: 7px`) reading "Add a channel".

**Add-channel modal**: full-window scrim `rgba(0,0,0,.5)`, dialog top-aligned 180px from
the top, 420px wide, `background: ink-700`, `border: 1px solid line-2`,
`border-radius: 10px`, `box-shadow: 0 20px 48px rgba(0,0,0,.6)`,
`padding: 18px 20px 20px`. Title "Add a channel" 16px/600. Body is a joined pair: a
118px platform select (dot + name + chevron) fused to a text input placeholdered
"channel name, or paste a link" (shared border, only outer corners rounded). Helper text
13px fg-3: "Paste a twitch.tv, youtube.com or kick.com link, or pick a platform and type
a name." Footer right-aligned, 8px gap: ghost **Cancel** (transparent, `border: 1px solid
line-2`, fg-2) and primary **Add channel** (`background: #3a3a3a`, no border), disabled
at `opacity: .6` until the field has content.

### 3. Broadcast view

Placeholder. Centered column, 12px gap: the 34px outlined square, "Broadcast" in
#e0e0e0, and "Go live to every platform at once from one window." in fg-4. Intentionally
empty — this is a named destination reserved for the next slice of work, not a designed
feature yet.

### 4. Settings view

Two columns filling the content area.

**Sub-nav** — 196px wide, `padding: 14px 10px`, `border-right: 1px solid line`, 2px gap.
A "Settings" section label padded `0 8px 8px`, then items: General, Appearance, Accounts,
Notifications, Keyboard shortcuts. Each item is 30px tall, `padding: 0 10px`,
left-aligned, `border-radius: 6px`, 14px, fg-2; hover `background: hover-row` + #e6e6e6;
selected `background: ink-700` + #f2f2f2.

**Content** — `padding: 22px 28px`, content capped at 520px. Every pane starts with its
title (17px/600, #f2f2f2) and a one-line fg-4 description, 20px below. Controls are
28px-tall rows: label on the left, control on the right,
`justify-content: space-between`. Group headings use the section-label style with 8px
below; groups are separated by a 1px `line` rule with 16px margins.

Toggle switch: 30px x 18px track, `border-radius: 999px`; off
`background: rgba(255,255,255,.14)`, on `background: #6f6f6f`; 12px white knob at
`top: 3px`, `left: 3px` → `15px`, 180ms.

- **General** — *Startup*: "Launch when the computer starts" (default on), "Reopen the
  channels I had open" (on). *Messages*: "Timestamps" (on), "Deleted messages" (on) —
  the same two globals as the pane popover, and they must stay in sync — plus
  "Keep the last" with a 132px select reading "500 messages". *Window*: "Keep on top of
  other windows" (off), "Close to the tray instead of quitting" (on).
- **Appearance** — *Theme*: "Appearance" with a three-way segmented control
  (Dark / Midnight / System) in the same trough style as the title-bar switcher but
  24px tall, `padding: 0 11px`, 13px text; "Message density" 132px select
  (Comfortable / Compact — compact drops message row padding from 5px to 2px);
  "Colour usernames by platform" toggle (on). *Text size*: "Default for new chats" with
  the same stepper as the pane popover, clamped 12–24px.
- **Accounts** — a single bordered list (`border: 1px solid line`,
  `border-radius: 9px`); rows `padding: 12px 14px`, 12px gap, `border-top: 1px solid
  line` on all but the first: an 8px platform dot (`opacity: .4` when not connected),
  a two-line block (name #ededed, detail 13px fg-4 — e.g. "xqc · full access",
  "LofiGirl · read only", "Not connected"), spacer, and a 26px ghost button reading
  Sign out or Sign in. Below the list, 13px fg-4: "Signing in lets you send messages and
  moderate. Read-only chats work without an account."
- **Notifications** / **Keyboard shortcuts** — deliberately empty: the 26px outlined
  square plus "Nothing here yet." in fg-4, `padding: 26px 0`.

---

## Interactions & behavior

- **Mode switch** — Chat / Broadcast / Settings, mutually exclusive. Selecting a channel
  tab implies Chat.
- **Tab click** = show only that channel. **Split icon** = add/remove that channel from
  the visible set, preserving the channel list's own order (not click order); the last
  visible pane cannot be un-split. **X** = remove the channel entirely; if that removed
  the only visible pane, fall back to the first remaining channel; if it removed the
  last channel, show the "No channels yet" state.
- **Filter** and **pane settings** are per-pane and independent; opening one pane's
  settings closes any other pane's settings.
- **Copy OBS link** shows a checkmark for 1.6s, then reverts.
- **Text size** steps through the fixed scale and clamps at both ends. Reset returns to
  15px.
- **Clear chat** empties only that pane and closes the popover.
- **Timestamps** and **Deleted messages** are global and reachable from two places; both
  must write the same state.
- No composer anywhere — the app is read-only, matching the repo README.

## State

Per window: `sources[]` (id, platform, label, status), `shown[]` (visible channel ids),
`view` ('chats' | 'broadcast' | 'settings'), `settingsPane`, `adding` (modal),
global `timestamps` / `deleted`, `theme`, `defaultSize`, and the General/Window flags.
Per channel: `size`, `filterOpen` (+ filter terms), `gearOpen`, `cleared`, `paused`
with an unread count.

## Assets

None. Every glyph in the mock is an inline SVG drawn in the lucide idiom
(24-unit viewBox, currentColor stroke, no fill) — use the repo's existing lucide
dependency rather than pasting these paths.

## Files in this bundle

- `Stream Chat v2.dc.html` — the cleaned-up design (this handoff).
- `Stream Chat.dc.html` — the earlier rough mock, for before/after comparison.

Open either file directly in a browser. Both are self-contained apart from
`support.js`, which is the preview runtime and is **not** part of the design.

## Screen map — where each piece lives in the repo

| Design area | Repo files to modify |
| --- | --- |
| Title bar, mode switcher, window controls | `src/renderer/src/components/TitleBar.tsx` |
| Channel tabs, split/remove actions | `src/renderer/src/components/ChannelTabs.tsx`, `components/PlatformIcon.tsx` |
| Pane header, filter bar | `src/renderer/src/components/ChatPane.tsx`, `components/ChatPaneBar.tsx` |
| Message rows, event accents, deleted state | `src/renderer/src/components/MessageRow.tsx` |
| Pane settings popover, OBS link, copy state | `src/renderer/src/components/ChatSettings.tsx`, `components/ChatLink.tsx` |
| Empty states, add-channel modal, view routing | `src/renderer/src/App.tsx`, `components/AddChannel.tsx` |
| Settings screen + sub-nav (new) | new `src/renderer/src/views/Settings/` |
| Broadcast placeholder (new) | new `src/renderer/src/views/Broadcast.tsx` |
| Tokens | `src/renderer/src/theme.ts`, `src/renderer/src/index.css` |
